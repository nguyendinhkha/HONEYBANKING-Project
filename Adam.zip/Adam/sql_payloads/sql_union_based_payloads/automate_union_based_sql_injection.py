import os
import subprocess
import time

REQUEST_DIR = '/home/kali/sql_payloads/sql_basic_payloads'
TECHNIQUE = "U"

def run_sqlmap(request_file, technique):
    command = [
        'sqlmap',
        '-r', request_file,
        '--batch',
        '--purge',
        '--technique=' + technique
    ]
    try:
        result = subprocess.run(command, capture_output=True, text=True, check=True)
        print(f"Attack on {request_file} with technique {technique} succeeded.")
    except subprocess.CalledProcessError as e:
        print(f"Attack on {request_file} with technique {technique} failed: {e}")
        print("Command output:", e.stdout)
        print("Command stderr:", e.stderr)

def main():
    payload_count = 0
    while payload_count < 1250:
        for request_file in os.listdir(REQUEST_DIR):
            if request_file.endswith('.txt'):
                full_path = os.path.join(REQUEST_DIR, request_file)
                print(f"Running SQLMap on {full_path} with technique {TECHNIQUE}")
                run_sqlmap(full_path, TECHNIQUE)
                payload_count += 1
                if payload_count >= 1250:
                    return

if __name__ == "__main__":
    main()
